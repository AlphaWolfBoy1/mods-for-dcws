-- Privs Shop

-- Global privs shop price, settable by /shop
shop.price1 = 2
shop.price2 = 4

-- Formspec
function shop.setform(pos)
	local spos = pos.x..","..pos.y..","..pos.z
	local formspec =
		"size[8,7]" ..
		default.gui_bg ..
		default.gui_bg_img ..
		default.gui_slots ..
		"label[3.3,0;Privs Shop]" ..
		"label[2,0.4;Fly]" ..
		"label[5,0.4;Noclip]" ..
		"list[nodemeta:" ..spos.. ";fly;2,1;1,1;]" ..
		"list[nodemeta:" ..spos.. ";noclip;5,1;1,1;]" ..
		"item_image[2,1;1,1;shop:coin]" ..
		"item_image[5,1;1,1;shop:coin]" ..
		"label[2,2;" .. shop.price1 .. " Coins per second]" ..
		"label[5,2;" .. shop.price2 .. " Coins per second]" ..
		"list[current_player;main;0,3;8,4;]"
	return formspec
end

function shop.buy(pos, listname, index, stack, player)
	local meta = minetest.get_meta(pos)
	local inv = meta:get_inventory()

	if listname == "fly" then
		local count = stack:get_count()
		inv:remove_item("fly", stack)
		local name = player:get_player_name()
		local time = count / shop.price1

		local q = playereffects.get_player_effects(name)
		for i=1, #q do
			if q[i].effect_type_id == "fly" then
				local countdown_fly = playereffects.get_remaining_effect_time(q[i].effect_id)
				local effectid_fly = playereffects.apply_effect_type("fly", time + countdown_fly, player)
				return
			end
		end

		local effectid_fly = playereffects.apply_effect_type("fly", time, player)

	elseif listname == "noclip" then
		local count = stack:get_count()
		inv:remove_item("noclip", stack)
		local name = player:get_player_name()
		local time = count / shop.price2

		local q = playereffects.get_player_effects(name)
		for i=1, #q do
			if q[i].effect_type_id == "noclip" then
				local countdown_noclip = playereffects.get_remaining_effect_time(q[i].effect_id)
				local effectid_noclip = playereffects.apply_effect_type("noclip", time + countdown_noclip, player)
				return
			end
		end

		local effectid_noclip = playereffects.apply_effect_type("noclip", time, player)
	end
end

minetest.register_alias("shop:shop", "shop:privs")
minetest.register_node("shop:privs", {
	description = "Privs Shop",
	tiles = {"xdecor_barrel_top.png^shop_wings.png",
		"xdecor_barrel_top.png",
		"xdecor_barrel_top.png^shop_wings.png",
		"xdecor_barrel_top.png^shop_wings.png",
		"xdecor_barrel_top.png^shop_wings.png",
		"xdecor_barrel_top.png^shop_wings.png"},
	is_ground_content = true,
	groups = {cracky=2, choppy=3, oddly_breakable_by_hand=1},
	paramtype2 = "facedir",
	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("infotext", "Shop for privs")
		local inv = meta:get_inventory()
		inv:set_size("fly", 1)
		inv:set_size("noclip", 1)
	end,
	on_rightclick = function(pos, node, clicker, itemstack)
		minetest.show_formspec(clicker:get_player_name(), "shop:privs", shop.setform(pos))
	end,
	on_metadata_inventory_put = function(pos, listname, index, stack, player)
		shop.buy(pos, listname, index, stack, player)
	end,
	allow_metadata_inventory_put = function(pos, listname, index, stack, player)
		local s = stack:get_name()
		local c = stack:get_count()
		if listname == "fly" then
			if s == "shop:coin" then
				return -1
			else
				return 0
			end
		elseif listname == "noclip" then
			if s == "shop:coin" then
				return -1
			else
				return 0
			end
		else
			return 0
		end
	end
})

-- playereffects registration
playereffects.register_effect_type("fly", "Fly mode available", nil, {"fly"},
	function(player)
		local playername = player:get_player_name()
		local privs = minetest.get_player_privs(playername)
		privs.fly = true
		minetest.set_player_privs(playername, privs)
	end,
	function(effect, player)
		local privs = minetest.get_player_privs(effect.playername)
		privs.fly = nil
		minetest.set_player_privs(effect.playername, privs)
	end,
	false,
	false)

playereffects.register_effect_type("noclip", "Noclip mode available", nil, {"noclip"},
	function(player)
		local playername = player:get_player_name()
		local privs = minetest.get_player_privs(playername)
		privs.noclip = true
		minetest.set_player_privs(playername, privs)
	end,
	function(effect, player)
		local privs = minetest.get_player_privs(effect.playername)
		privs.noclip = nil
		minetest.set_player_privs(effect.playername, privs)
	end,
	false,
	false)

minetest.register_craft({
	output = "shop:privs",
	recipe = {
		{"group:wood", "default:mese", "group:wood"},
		{"group:wood", "default:goldblock", "group:wood"},
		{"group:wood", "default:diamondblock", "group:wood"}
	}
})

minetest.register_node(":ugx:carbonbrick", {
	description = ("Carbon Brick"),
	drawtype = "normal",
	tiles = { "carbonbrick.png" },

	groups = { cracky = 1 },
})

minetest.register_node(":ugx:xdecorwood", {
	drawtype = "normal",
	tiles = { "xdecor_wood.png" },

	groups = { choppy = 3 },
})

minetest.register_node(":ugx:xdecorpressure", {
	drawtype = "allfaces_optional",
	tiles = { "xdecor_pressure_stone.png" },

	groups = { cracky = 1 },
})

minetest.register_node(":ugx:softblueglass", {
	description = ("soft blue glass"),
	drawtype = "glasslike",
  sunlight_propagates = true,
   use_texture_alpha = true,
  paramtype = "light",
	tiles = { "softblueglass.png" },

	groups = { cracky = 1 },
})

minetest.register_node(":default:NOiaccidenttallydeleteditandnowidkhowtoremakeitaaaasomeomehelpme", {
	description = ":| plus also kts a bad idea to use admin chest as when we move items and chests using wrench in inv admin chests and any protected chest aren't supported. ( ͠° ͟ʖ ͡°)",
	tiles = {"xdecor_glyph13.png"},
	groups = {snappy=3, cracky=2},
   drawtype = "signlike",
	sunlight_propagates = true,
	paramtype2 = "wallmounted",
  legacy_wallmounted = true,
   walkable = false,
})

minetest.register_craft({
	output = "ugx:carbonbrick 2",
	recipe = {
		{"ugx:rusty_block", "default:brick"},
	}
})


minetest.register_craft({
	output = "ugx:softblueglass",
	recipe = {
		{"ugx:bluething", "default:glass"},
	}
})

minetest.register_craft({
	output = "ugx:teleport_fruit",
	recipe = {
		{"default:mese", "default:mese", "default:stone"},
		{"default:apple", "default:apple", "default:apple"},
		{"infinitytools:compressed_mese", "default:diamondblock", "default:apple"}
	}
})

minetest.register_node(":ugx:blackbottom", {
	drawtype = "normal",
	tiles = { "bones_bottom.png" },

	groups = { choppy = 3 },
})

minetest.register_node(":ugx:railcrossblocktransparent", {
	drawtype = "glasslike",
	tiles = { "carts_rail_crossing.png" },

	groups = { choppy = 3 },
})

minetest.register_node(":ugx:carts_cart_top", {
	drawtype = "normal",
	tiles = { "carts_cart_top.png" },

	groups = { choppy = 3 },
})

minetest.register_node(":ugx:xpanes_edge", {
	drawtype = "normal",
	tiles = { "xpanes_edge.png" },

	groups = { choppy = 3 },
})

minetest.register_node(":ugx:tnt_blast", {
	drawtype = "normal",
	tiles = { "tnt_blast.png" },

	groups = { choppy = 3 },
})

minetest.register_node(":ugx:susleaves", {
	drawtype = "normal",
  sunlight_propagates = true,
	tiles = { "susleaves.png" },

	groups = { choppy = 3 },
})

minetest.register_node(":ugx:sustree", {
	drawtype = "normal",
	tiles = { "sustree.png" },

	groups = { choppy = 3 },
})

minetest.register_node(":ugx:test16", {
	drawtype = "normal",
	tiles = { "test16.png" },

	groups = { choppy = 3 },
})

minetest.register_node(":ugx:test16_noborder", {
	drawtype = "normal",
	tiles = { "test16_noborder.png" },

	groups = { choppy = 3 },
})

minetest.register_node(":ugx:tnt_bottom", {
	drawtype = "normal",
   sunlight_propagates = true,
	tiles = { "tnt_bottom.png" },

	groups = { choppy = 3 },
})

minetest.register_node(":xdecor:rooteddecoplant", {
        paramtype = "light",
        drawtype = "plantlike_rooted",
        tiles = {{
                name = "default_grass.png",
                align_style = "world",
                scale = 8,
        }},
        special_tiles = {"testnodes_plantlike.png^testnodes_plantlike_meshoptions.png"},
        groups = {unbreakable=1},
})

minetest.register_node(":ugx:community_mod_material_diamond", {
	drawtype = "normal",
	tiles = { "community_mod_material_diamond.png" },

	groups = { choppy = 3 },
})

minetest.register_node(":ugx:community_mod_material_gold", {
	drawtype = "normal",
	tiles = { "community_mod_material_gold.png" },

	groups = { choppy = 3 },
})

-- y tho


minetest.register_craft({
    output = 'default:diamond',
    recipe = {
        {'ugx:griefer_soul'},
    },
})

-- Register the recipe for specialblocks:yellowbrickys
minetest.register_craft({
    output = 'specialblocks:yellowbrickys',
    recipe = {
        {'wool:yellow', 'default:brick'},
    }
})

-- Register the recipe for sponge:sponge_wet
minetest.register_craft({
    output = 'sponge:sponge_wet',
    recipe = {
        {'bucket:bucket_water'},
        {'sponge:sponge'},
    },
    replacements = {{"bucket:bucket_water", "bucket:bucket_empty"}}
})

-- Register the recipe for specialblocks:dot
minetest.register_craft({
    output = 'specialblocks:dot',
    recipe = {
        {'default:wood', '', 'default:wood'},
        {'', 'xpanes:abriglass_pane_blue_flat', ''},
        {'default:wood', '', 'default:wood'},
    }
})





-- Define the custom block
minetest.register_node(":ugx:1cactus_block", {
    description = "Custom Cactus Block",
    tiles = {"cactus_top.png", "cactus_top.png", "cactus_side.png", "cactus_side.png", "cactus_side.png", "cactus_side.png"},
    is_ground_content = false,
    groups = {cracky = 3, stone = 1, not_cuttable=1},
})


-- Define the shop:surprise block
minetest.register_node("shop:surprise", {
    description = "Surprise Block",
    tiles = {"surprise.png"},
    is_ground_content = false,
    groups = {cracky = 3, stone = 1, not_cuttable=1},
    drop = "",  -- No default drop, we'll handle this in the on_dig function

    on_dig = function(pos, node, digger)
        if digger and digger:is_player() then
            local player_name = digger:get_player_name()
            local player_inv = digger:get_inventory()
            local actions = {"drop_item", "replace_block", "kill_player"}
            local action = actions[math.random(#actions)]

            if action == "drop_item" then
                -- Drop a random item
                local items = {
                    "default:apple", "default:coal_lump", "default:diamond", 
                    "default:gold_ingot", "default:steel_ingot", "default:stick"
                }
                local item = items[math.random(#items)]
                minetest.add_item(pos, item)
                minetest.chat_send_player(player_name, "You got a " .. item .. "!")

            elseif action == "replace_block" then
                -- Replace with a random block
                local blocks = {
                    "default:stone", "tnt:tnt_burning", "default:dirt_with_grass_footsteps", 
                    "default:mese", "default:wood", "default:glass"
                }
                local block = blocks[math.random(#blocks)]
                minetest.set_node(pos, {name = block})
                minetest.chat_send_player(player_name, "The surprise block turned into " .. block .. "!")

            elseif action == "kill_player" then
                -- Kill the player
                digger:set_hp(0)
                minetest.chat_send_all(player_name .. " was killed by the surprise block!")
            end
        end
    end
})

-- Registering the blocks with simple properties

minetest.register_node(":ugx:3stone", {
    drawtype = "normal",
    tiles = { "3stones.png" },
    groups = { choppy = 3 },
})

minetest.register_node(":ugx:3bigleaves", {
    drawtype = "allfaces",
    sunlight_propagates = true,
    use_texture_alpha = "blend",
    tiles = { "3bigleaves.png" },
    groups = { choppy = 3 },
})

minetest.register_node(":ugx:weirdwoodframe", {
    drawtype = "normal",
    tiles = { "weirdwoodframe.png" },
    groups = { choppy = 3 },
})

minetest.register_node(":ugx:wowwood", {
    drawtype = "normal",
    tiles = { "wowwood.png" },
    groups = { choppy = 3 },
})

minetest.register_node(":ugx:altstonebrick", {
    description = "Stone Brick Alternative",
    drawtype = "normal",
    tiles = { "stonebrickalt.png" },
    groups = { choppy = 3, not_cuttable = 1},
})

minetest.register_node(":ugx:lanternlow", {
    drawtype = "normal",
    light_source = 10,
    tiles = { "lanternlow.png" },
    groups = { choppy = 3 },
})

minetest.register_node(":ugx:2bookshelf", {
    drawtype = "normal",
    tiles = { "2bookshelf.png" },
    groups = { choppy = 3 },
})

-- Registering the cobblebricks block

minetest.register_node(":ugx:cobblebricks", {
    description = "Cobble Bricks",
    drawtype = "normal",
    tiles = { "cobblebricks.png" },
    groups = { choppy = 3 },
})

-- Crafting recipe for cobblebricks
minetest.register_craft({
    output = 'ugx:cobblebricks',
    recipe = {
        {'default:cobble', 'default:cobble'},
        {'default:cobble', 'default:dirt'},
    }
})

          minetest.register_node(":testnodes:alpha_true", {
                  description = "Alpha Test Node",
                  drawtype = "liquid",
                  use_texture_alpha = true,
                  paramtype = "light",
                  tiles = {
                          "crystal.png",
                  },
                  groups = { dig_immediate = 3 },
          })

          minetest.register_node(":testnodes:alpha_true_normal", {
                  description = "Alpha Test Node (normalized texture)",
                  drawtype = "liquid",
                  paramtype = "light",
                  tiles = {
                          "crystal_normal.png",
                  },
                  use_texture_alpha = true,
                  groups = { dig_immediate = 3 },
          })

local rotate = function(pos, node)
        local p2 = node.param2
        p2 = p2 + 1
        if p2 > 3 then
                p2 = 0
        end
        minetest.set_node(pos, {name=node.name, param2=p2})
end


minetest.register_node("shop:4dir_stair", {
        description = "4dir Test Stair",
        paramtype2 = "4dir",
        drawtype = "nodebox",

        node_box = {
                type = "fixed",
                fixed = {
                        {-0.5, -0.5, -0.5, 0.5, 0, 0.5},
                        {-0.5, 0, 0, 0.5, 0.5, 0.5},
                },
        },
        paramtype = "light",

        tiles = {
                "testnodes_normal.png",
        },
        groups = { dig_immediate = 3 },
        on_rightclick = rotate,
})